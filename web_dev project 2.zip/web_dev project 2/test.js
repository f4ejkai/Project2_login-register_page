var express = require('express');
var router = express.Router();
var fs = require('fs');
var path = require('path');
var ejs = require('ejs');
//save cookie to the local
var session = require('express-session');
var cookieParser = require('cookie-parser');
// var imghtml = require('./static/index')
var expImg = express();
//connect to our Mongo
var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/";

//enters the login page
router.get('/login', function (req, res) {
    //read login.html
    fs.readFile('/nodeCodeTest/node_express_app/myapp/static/login.html', function(err,data) {
        if (err) return console.log(err)
        res.setHeader('Content-Type', 'text/html');
        res.send(data)
        // console.log('async: ' + data.toString())
    })
})

//Enters the register page
router.get('/regin', function (req, res) {
    fs.readFile('/nodeCodeTest/node_express_app/myapp/static/regin.html', function(err,data) {
        if (err) return console.log(err)
        res.setHeader('Content-Type', 'text/html');
        res.send(data)
    })
})

//trigger the event for login
router.get('/process_get', function (req, res) {
    var response = {
        "userName":req.query.userName,
        "passWord":req.query.passWord
    };
    // put user name and password information into Cookies
    res.cookie('userInfo',response);
    // res.end(JSON.stringify(response));
    MongoClient.connect(url, { useNewUrlParser: true }, function(err, db) {
        if (err) throw err;
        //db in database is the fristNode form is userInfo，save login information here
        var dbo = db.db("fristNode");
        dbo.collection("userInfo").find().toArray((err, result)=> { // return all the data we gathered
            if (err) throw err;
            console.log(result);
            let flag = false
            result.forEach( item => {
                if (item.name == req.query.userName) {
                    flag = true
                }
                else {
                    flag = false
                }
            })
            if(flag) {
                console.log(result, 'login success');
                // redirect login success page
                fs.readFile('/nodeCodeTest/node_express_app/myapp/static/test.html', function(err,data) {
                    if (err) return console.log(err)
                    // res.setHeader('Content-Type', 'text/html');
                    res.end(data,JSON.stringify(response))
                })
            } else {
                res.render('loginerror');
            }
            db.close();
        });
    });
})

//click and trigger event to register
router.get('/regin_get', function (req, res) {
    var response = {
        "userName":req.query.userName,
        "passWord":req.query.passWord
    };
    // put user name and passsword into cookie
    res.cookie('userInfo',response);
    MongoClient.connect(url, { useNewUrlParser: true }, function(err, db) {
        if (err) throw err;
        var dbo = db.db("fristNode");
        var myobj = {name: req.query.userName,password: req.query.passWord};
        dbo.collection("userInfo").insertOne(myobj, function(err, res) {
            if (err) throw err;
            console.log("Register Success");
            db.close();
        });
    });
    fs.readFile('/nodeCodeTest/node_express_app/myapp/static/login.html', function(err,data) {
        if (err) return console.log(err)
        res.setHeader('Content-Type', 'text/html');
        res.end(data,JSON.stringify(response))
    })
// output in JSON format
})

module.exports = router;
